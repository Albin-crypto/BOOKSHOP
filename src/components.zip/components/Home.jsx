import { Link } from "react-router-dom";
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Carousel from 'react-bootstrap/Carousel';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import ExampleCarouselImage from "./images/Book.jpg";
import Card from 'react-bootstrap/Card';
import { useContext } from "react"; // use useContext to access context
import { mycontext } from './context'; // import the context

function Home() {
  // Correct way to use context
  const { MData } = useContext(mycontext); 
  console.log(MData);

  return (
    <div class="">
      <div>
        <Navbar expand="lg" className="bg-body-tertiary">
          <Container>
            <Navbar.Brand href="/">Books Shop</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link href="about">About  </Nav.Link>
                <Nav.Link href="product">Books</Nav.Link>
                <Nav.Link href="contact">Contact</Nav.Link>
                <NavDropdown title="Sign up" id="basic-nav-dropdown">
                  <NavDropdown.Item href="login">login</NavDropdown.Item>
                  <NavDropdown.Item href="registeration">
                    Registeration
                  </NavDropdown.Item>
                </NavDropdown>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </div>
      
      <Carousel>
        <Carousel.Item interval={2000}>
          <img src={ExampleCarouselImage} alt="First slide" style={{ width: "100%", height: "auto" }} />
          <Carousel.Caption>
            <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={2000}>
          <img src={ExampleCarouselImage} alt="First slide" style={{ width: "100%", height: "auto" }} />
          <Carousel.Caption>
            <h3>Second slide label</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item interval={2000}>
          <img src={ExampleCarouselImage} alt="First slide" style={{ width: "100%", height: "auto" }} />
          <Carousel.Caption>
            <h3>Third slide label</h3>
            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel> 
      
      <br/>
      <h3><b>India's Top reads</b></h3>
<div style={{display:"flex"}}>
      {/* Dynamically render cards based on MData */}
      {MData && MData.map((data, index) => (
        <Card key={index} style={{ width: "200px", marginLeft: "40px"}}>
          <Card.Img variant="top" src={data.Img} style={{ width: "200px", height: "250px" }} />
          <Card.Body>
            <Card.Title>{data.Name ||data.Author}</Card.Title>
            <Card.Text>{data.description}</Card.Text>
            <Button variant="primary">Cart</Button>
          </Card.Body>
        </Card>
      ))}
</div>
    </div>
  );
}

export default Home;

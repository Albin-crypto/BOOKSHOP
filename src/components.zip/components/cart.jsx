// 
import React, { useContext } from 'react';
import { mycontext } from './context';
import { Card, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

function Cart() {
  const { cart, setCart } = useContext(mycontext);
  const navigate = useNavigate()
  const nav= useNavigate()

 

  const removeItem = (e) => {
    const removeItemId = parseInt(e.target.id);
    const newItems = cart.filter((item) => item.Id !== removeItemId);
    setCart(newItems);
  };

  const addQty = (id) => {
    const newQty = cart.map((item) =>
      item.Id === id ? { ...item, qty: (item.qty||1) + 1 } : item
    );
    setCart(newQty);
  };

  const removeQty = (id) => {
    const newQty = cart.map((item) =>
      item.Id === id && item.qty > 1 ? { ...item, qty: (item.qty||1) - 1 } : item
    );
    setCart(newQty);
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.Price * (item.qty||1), 0);
  };
   
  const amount = calculateTotal()

  const handleNavigate=()=>{
    navigate("/payment",{state:amount})
  }
 

  return (
    <div>
      <div>
      </div>
      <div class="head"className="container">
        <div className="row">
          {cart.map((item) => (
            <Card key={item.Id} className="w-25 col-4">
              <Card.Img variant="top" src={item.Img} className="w-50"style={{width:"300px",height:"290px"
              }} />
              <Card.Body>
                <Card.Title>{item.Name}</Card.Title>
                <Card.Text>
                  Price: ₹{item.Price * (item.qty||1)} {/* Multiply price by quantity */}
                </Card.Text>
                <Card.Text>Quantity: {item.qty}</Card.Text>
               <button class="btnr"><p onClick={() => removeQty(item.Id)}>Remove Qty</p></button> 
               &nbsp; <button class="btna"><p onClick={() => addQty(item.Id)}>Add Qty</p></button><br/>
               <br/>
                <button class="btnr"><p id={item.Id} onClick={removeItem}>
                  Remove Item
                </p></button>
              </Card.Body>
            </Card>
          ))}
        </div>
        <div className="payment-section" style={{marginTop:"100px"}}>
          {cart.length > 0 && (
            <>
              <h3>Total Amount: ₹{calculateTotal()}</h3>
              <Button style={{backgroundColor:"green"}} variant="primary" onClick={handleNavigate}>
                Proceed to Payment
              </Button>
              <Link to={"/"} style={{ textDecoration: "none", marginTop: "10px", display: "block" }}>
            <button className="btnl">
              Home
            </button>
          </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
export default Cart
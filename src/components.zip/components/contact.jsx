import React from 'react'
import { useNavigate } from 'react-router-dom'

export default function Contact() {
    const nav = useNavigate();
    function handleClick()
    {
        nav('/')  
    }
  return (
    <div class="  ">
    <button class="btn1" onClick={handleClick}>Home</button>
        <p class="h1"><b>Please Contact this Number: 89213445445</b></p>
        <p class="h2"><b>Please Contact this Email: abook@gmail.com</b></p>
        <img src="https://cdn.pixabay.com/photo/2022/12/01/00/13/antique-7627999_960_720.jpg" style={{width:"1272px",height:"637px"}}/>
        
    </div>
  )
}

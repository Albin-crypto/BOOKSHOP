import React from "react"
import { useNavigate } from "react-router-dom"

export default function About(props) {

    // console.log("props",props.data);
    const propData=props.data
    
    const nav = useNavigate();
    function handleClick()
    {
        nav('/')  
    }
    return (
        <div class="head">
         <h1 class="h1">{propData}</h1>
         <button class="btn1" onClick={handleClick}>Back</button>
        <h1> </h1>
        <img src="https://cdn.pixabay.com/photo/2018/07/01/20/01/music-3510326_1280.jpg"/>

       
        {/* one way to print output */}

        </div>
    )
}
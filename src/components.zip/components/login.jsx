import { useContext, useState } from 'react';
import { useNavigate,Link } from 'react-router-dom';
import { mycontext } from './context';

function Login() {
  const { user, setLogUser, setLogSuccess } = useContext(mycontext);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const nav = useNavigate();

  function loginBtn() {
    const loggedUser = user.find(
      (userData) => userData.email === email && userData.password === password
    );

    if (loggedUser) {
      // Check if the user is banned
      if (loggedUser.banned) {
        setError('User is banned. Please contact support.');
        return;
      }

      setLogUser(loggedUser); // Set logged user directly instead of spreading
      setLogSuccess(true); // Update success state
      alert('Login successful !!!');
      nav('/'); // Redirect to home page
    } else {
      setError('Invalid email or password');
    }
  }

  return (
    <div>
      <h1>Login Page</h1>
      <div>
        <label>Email:</label>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input
          className="input"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <br />
        <br />
        <label>Password:</label>
        &nbsp;
        <input
          className="input"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />
        <br />
        <button className="btnl" onClick={loginBtn}>Login</button>
        <button className="btnl"> < Link to={"/registeration"} className="link"> Registeration </Link></button>
        {error && <p style={{ color: 'red' }}>{error}</p>}
      </div>
    </div>
  );
}

export default Login;

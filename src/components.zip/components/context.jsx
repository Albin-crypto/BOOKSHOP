import { createContext } from "react";
export const mycontext=createContext()
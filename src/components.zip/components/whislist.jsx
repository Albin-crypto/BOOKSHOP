import React, { useContext } from 'react'
import { mycontext } from './context'
import {  useNavigate } from "react-router-dom";
function Whislist() {
    const { like, setLike } = useContext(mycontext);
    const nav = useNavigate();
    function handleRemove(product) {
        setLike(like.filter(item => item !==     product))
    }
    function confirmRemove(product) {
        if (window.confirm(`Are you sure you want to remove "${product.Name}" from Wishlit?`)) {
            handleRemove(product)
        }
    }
    return (
        <div class="head" style={{ display: "flex", flexWrap: "wrap", gap: "20px",marginTop:"0px" }}>
            {
                like.map((data) => {
                    // if (data.Item=="mobile") { // Condition: Only render products that are in stock
                    return (
                        <div class="card" key={data.id} style={{ }}>
                                            <p><img src={data.Img} alt={data.Name} width={200} height={260} /></p>
                <p style={{ height: "50px", overflowY: "scroll" }}><b>{data.Name}</b></p>
                <p>Language :{data.Language}</p>
                <p>Author :{data.Author}</p>
                <p>Publisher :{data.Publisher}</p>
                <p>Price: ₹{data.Price}</p>   
                            <button class="like"onClick={() => confirmRemove(data)}>Remove</button>
                           &nbsp; <button class="cart" onClick={() => nav('/')}>Home</button> 
                        </div>
                    );
                    // } else {
                    //     return null; // Don't render anything if the condition is not met
                    // }
                })
            }
        </div>
    )
}

export default Whislist     
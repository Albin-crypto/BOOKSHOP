import React, { useContext } from 'react';
import { mycontext } from './context';
import { Link } from 'react-router-dom';

function Bannedcust() {
  const { user } = useContext(mycontext);

  
  const bannedUsers = user.filter((data) => data.banned);

  return (
    <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "20px" }}>
      {bannedUsers.length > 0 ? (
        bannedUsers.map((data) => (
          <div key={data.id} style={{ maxWidth: "300px", maxHeight: "500px", border: "1px solid #ccc", padding: "10px", margin: "10px" }}>
            <p style={{ height: "50px", overflowY: "auto" }}>
              <b>Customer Name: {data.name}</b><br />
              <b>Customer Email: {data.email}</b><br />
              <b>Customer Password: {data.password}</b><br />
              <b>Status: Banned</b>
            </p>
            <Link to={"/login"} style={{ textDecoration: "none", marginTop: "10px", display: "block" }}>
              <button style={{ backgroundColor: "orange", color: "white", padding: '5px 10px' }}>
                Login
              </button>
            </Link>
          </div>
        ))
      ) : (
        <p>No banned customers found.</p>
      )}
    </div>
  );
}

export default Bannedcust;

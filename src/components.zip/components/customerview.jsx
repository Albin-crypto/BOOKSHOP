import React from 'react';
import { mycontext } from './context';
import { useContext } from 'react';
import { Link } from 'react-router-dom';


function Customerview() {
  const { user, setUser } = useContext(mycontext); // Get the user array and the setter for updating it

  function handleApprove(data) {
    // Navigate to login when approved
    alert("mail sended")
  }

  function handleBanned(data) {
    // Update the user state to set the banned status to true for the selected user
    const updatedUsers = user.map((u) =>
      u.email === data.email ? { ...u, banned: !u.banned } : u
    );
    setUser(updatedUsers); // Update the context with the new list of users
  }

  return (
    <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "20px" }}>
      {user.map((data, index) => (
        <div key={data.id} style={{ maxWidth: "300px", maxHeight: "500px", border: "1px solid #ccc", padding: "10px", margin: "10px" }}>
          <p style={{ height: "50px", overflowY: "" }}>
            <b>Customer Name: {data.name}</b><br />
            <b>Customer Email: {data.email}</b><br />
            <b>Customer Password: {data.password}</b><br />
            <b>Status: {data.banned ? "Banned" : "Active"}</b>
          </p>
          <br />
          <br />
          <button className="btnla"
            style={{ backgroundColor: "green", color: 'white', marginBottom: "5px" }}
            onClick={() => handleApprove(data)}
            disabled={data.banned} // Disable approve button if banned
          >
            Approve
          </button>
          &nbsp;
          <button className="btnlb"
            onClick={() => handleBanned(data)}
          >
            {data.banned ? "Unban" : "Ban"}
          </button>
          <Link to={"/"} style={{ textDecoration: "none", marginTop: "10px", display: "block" }}>
            <button className="btnl">
              Home
            </button>
          </Link>
        </div>
      ))}
    </div>
  );
}

export default Customerview;

import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

function Payment() {
    const amount = useLocation().state;
    const navigate = useNavigate();
    const [visible, setVisible] = useState(true);
    
    const currentDate = new Date(Date.now());

    // Function to format date to dd/mm/yyyy
    function formatDateToDDMMYYYY(date) {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    }

    // Function to add days to a date
    function addDays(date, days) {
        const newDate = new Date(date);
        newDate.setDate(newDate.getDate() + days);
        return newDate;
    }

    // Convert current date to dd/mm/yyyy format
    const formattedDate = formatDateToDDMMYYYY(currentDate);

    // Add 7 days to the current date and format it
    const dateAfter7Days = addDays(currentDate, 7);
    const formattedDateAfter7Days = formatDateToDDMMYYYY(dateAfter7Days);

    useEffect(() => {
        // Hide the message or navigate away after 10 seconds
        const timer = setTimeout(() => {
            setVisible(false); // To hide the message
            // Optionally navigate to another page after hiding the message
            navigate('/'); // Redirect to home page or any other route
        }, 10000); // 10 seconds in milliseconds

        // Cleanup timer if the component is unmounted
        return () => clearTimeout(timer);
    }, [navigate]);

    if (!visible) {
        return null; // Hide the component when it's no longer visible
    }

    return (
        <div style={{ width: '100vw', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', color: 'white', backgroundColor: 'green', width: '80%', height: '300px', border: '1px dotted red', borderRadius: '30px' }}>
                <h2>
                    Payment of ₹{amount}/- is successful! Your order will be delivered on or before {formattedDateAfter7Days}
                </h2>
            </div>
        </div>
    );
}

export default Payment;

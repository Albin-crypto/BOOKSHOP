import { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { mycontext } from './context';

function Registration() {
  const { user, setUser } = useContext(mycontext);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const nav = useNavigate();

  const isUserAlreadyRegistered = () => {
    return user.find((data) => data.email === email);
  };

  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password) => {
    return password.length >= 6;
  };

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent form submission

    // Validate email
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address.");
      return;
    } else {
      setEmailError("");
    }

    // Validate password
    if (!validatePassword(password)) {
      setPasswordError("Password must be at least 6 characters long.");
      return;
    } else {
      setPasswordError("");
    }

    // Check if user is already registered
    if (isUserAlreadyRegistered()) {
      alert("User already registered. Please use a different email.");
      return;
    }

    // Register user
    const userData = { name, email, password };
    setUser([...user, userData]);

    // Navigate to login page
    nav("/login");
    console.log("Registered user:", userData);
  };

  return (
    <div className="card2" style={{ textAlign: "center" }}>
      <h1>Register</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Full Name:</label>
          &nbsp;<input
            className="input"
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <br />
          
          <label>Gender:</label>
          &nbsp;<input type="radio" value="male" name="gender" required /> Male
          &nbsp;<input type="radio" value="female" name="gender" required /> Female
          <br />
          <br />

          <label>Email:</label>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
            className="input"
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setEmailError(""); // Clear email error on input change
            }}
            required
          />
          <br />
          {emailError && <p style={{ color: "red" }}>{emailError}</p>}
          <br />

          <label>Password:</label>
          &nbsp;&nbsp;<input
            className="input"
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setPasswordError(""); // Clear password error on input change
            }}
            required
          />
          {passwordError && <p style={{ color: "red" }}>{passwordError}</p>}
          <br />
          <br />

          <button className="btnl" type="submit">
            <span className="btn-text-one">Submit</span>
          </button>
        </div>
      </form>
    </div>
  );
}

export default Registration;

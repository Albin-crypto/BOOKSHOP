import React from 'react'
import { Link } from "react-router-dom"

function admin() {
  return (
    <div class="ahead">
        
        <button class="btnp"><Link to={"/productview"}>Product View</Link></button>
        <button class="btnp"><Link to={"/customerview"}>Customer View</Link></button>
        <button class="btnp"><Link to={"/bannedcust"}> Banned Customer </Link></button>
        <button class="btnp"><Link to={"/"}> Home </Link></button>
        <p>Welcome admin page</p>



    </div>
  )
}

export default admin
import { useContext, useState } from "react";
import { mycontext } from './context';
import { Link, useNavigate } from "react-router-dom";

export default function Product() {
  const { PData, like, setLike, cart, setCart, logSuccess } = useContext(mycontext);
  const [search, setSearch] = useState("");
  const [filteredProducts, setFilteredProducts] = useState(PData);
  const nav = useNavigate();

  // Function to handle adding to wishlist
  function handleAddToWishlist(product) {
    if (!logSuccess) { // Check if the user is logged in
      alert('Please log in to add items to the wishlist.');
      nav('/login'); // Redirect to login page if user is not logged in
      return;
    }
    if (like.includes(product)) {
      alert('Product is already in the wishlist.');
    } else {
      setLike([...like, product]);
    }
  }

  // Function to handle adding to cart
  function handleAddToCart(product) {
    if (!logSuccess) { // Check if the user is logged in
      alert('Please log in to add items to the cart.');
      nav('/login'); // Redirect to login page if user is not logged in
      return;
    }
    if (cart.includes(product)) {
      alert('Product is already in the cart.');
    } else {
      setCart([...cart, product]);
    }
  }

  // Handle search functionality
  const handleSearch = (e) => {
    const query = e.target.value;
    setSearch(query);

    const filtered = PData.filter(item => {
      return (
        item.Name.toLowerCase().includes(query.toLowerCase()) ||
        item.Publisher.toLowerCase().includes(query.toLowerCase()) ||
        item.Item.toLowerCase().includes(query.toLowerCase()) ||
        item.Language.toLowerCase().includes(query.toLowerCase()) ||
        item.Author.toLowerCase().includes(query.toLowerCase()) ||
        item.Price.toString().includes(query)
      );
    });

    setFilteredProducts(filtered);
  };

  return (
    <div className="head">
      <h1>Product Page</h1>
      <button className="btnp" onClick={() => nav('/')}>Home</button>
      &nbsp;<button className="btnp"><Link to="/wishlist">Wishlist</Link></button>
      &nbsp;<button className="btnp"><Link to="/cart">Cart</Link></button>
      &nbsp;<input
        style={{ width: "260px", height: "29px" }}
        type="text"
        onChange={handleSearch}
        value={search}
        placeholder="🔎 Search Product..."
      />
      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px", marginTop: "50px" }}>
        {filteredProducts.map((data) => (
          <div className="card1" key={data.id}>
            <img src={data.Img} alt={data.Name} width={200} height={260} />
            <p style={{ height: "50px", overflowY: "scroll" }}>
              <b>{data.Name}</b>
            </p>
            <p>Language: {data.Language}</p>
            <p>Author: {data.Author}</p>
            <p>Publisher: {data.Publisher}</p>
            <p>Price: ₹{data.Price}</p>
            <button
              className="like"
              onClick={() => handleAddToWishlist(data)}
            >
              {like.includes(data) ? 'Liked' : 'Like'}
            </button>
            &nbsp;
            <button
              className="cart"
              onClick={() => handleAddToCart(data)}
            >
              {cart.includes(data) ? 'Added' : ' Add to cart'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
